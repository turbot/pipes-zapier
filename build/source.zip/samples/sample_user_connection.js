module.exports = {
  config: {
   max_items: 5000
  },
  created_at: '2023-03-17T15:59:13+05:30',
  created_by: {
   avatar_url: 'https://avatars.githubusercontent.com/u/38319418?v=4',
   created_at: '2021-11-25T05:43:02Z',
   display_name: 'Steampipe User',
   handle: 'steampipeuser1',
   id: 'u_c6fi4phe4mvf24h22cjg',
   status: 'accepted',
   updated_at: '2022-12-15T14:00:21Z',
   version_id: 10
  },
  created_by_id: 'u_c6fi4phe4mvf43h24cjg',
  handle: 'hackernews',
  id: 'c_cga41udglus66t4t57m0',
  identity_handle: 'steampipeuser1',
  identity_id: 'u_c6fi4phe4mvf24h22cjg',
  identity_type: 'user',
  plugin: 'hackernews',
  type: 'connection',
  updated_at: null,
  updated_by: null,
  updated_by_id: '',
  version_id: 1
 };