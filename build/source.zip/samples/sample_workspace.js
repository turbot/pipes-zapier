module.exports = {
  id: 'w_abc12345de67fg8hijkl',
  workspace_id: 'w_abc12345de67fg8hijkl',
  handle: 'workspace1',
  database_name: 'abcd0e',
  host: 'usea1.db.steampipe.io',
  workspace: {
    id: 'w_abc12345de67fg8hijkl',
    handle: 'workspace1',
    identity_id: 'u_a1bc2def3ghi45j67klm',
    hive: 'usea1-0001',
    host: 'usea1.db.steampipe.io',
    database_name: 'abcd0e',
    state: 'running',
    api_version: '1.7.19',
    cli_version: '0.19.2',
    created_at: '2022-10-27T09:36:36Z',
    created_by_id: 'u_a1bc2def3ghi45j67klm',
    updated_at: '2023-03-19T05:03:01Z',
    deleted_at: null,
    version_id: 1
  },
  identity_id: 'u_a1bc2def3ghi45j67klm',
  identity: {
    id: 'u_a1bc2def3ghi45j67klm',
    type: 'user',
    handle: 'dummyuser01',
    display_name: 'Steampipe User'
  },
  role: 'owner'
};
