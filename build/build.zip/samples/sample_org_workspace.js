module.exports = {
  id: 'w_steampipetest9ie818g',
  handle: 'zapiertest1',
  identity_id: 'o_cgc0aiofjtuv00ie423g',
  hive: 'usea1-0001',
  host: 'usea1.db.steampipe.io',
  database_name: 'qgasot',
  state: 'pending',
  api_version: '',
  cli_version: '',
  created_at: '2023-03-20T07:53:50Z',
  created_by_id: 'u_c6fi4phe4mvf26h42cjg',
  created_by: {
    id: 'u_c6fi4phe4mvf12h33jpg',
    handle: 'steampipeuser01',
    display_name: 'Steampipe User',
    avatar_url: 'https://avatars.githubusercontent.com/u/38319418?v=4',
    status: 'accepted',
    version_id: 10,
    created_at: '2021-11-25T05:43:02Z',
    updated_at: '2022-12-15T14:00:21Z'
  },
  updated_at: '2023-03-20T07:53:54Z',
  deleted_at: null,
  version_id: 1
};