module.exports = {
  id: "7c70d166e9c1ecf4545fb00e63322762",
  arn: "arn:aws:s3:::bucket",
  name: "bucket",
};
